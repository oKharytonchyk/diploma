create type          SYS_PLSQL_74815_DUMMY_1 as table of number;
/


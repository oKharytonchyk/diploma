create PACKAGE PLACE_PACKAGE AS
  TYPE T_PLACE IS RECORD (
  place_id NUMBER,
  address VARCHAR2(60),
  room_number NUMBER,
  schedule VARCHAR2(11)
  );

  TYPE T_PLACE_TWO IS RECORD (
  address VARCHAR2(60),
  place_id NUMBER
  );

  TYPE T_PLACE_TABLE IS TABLE OF T_PLACE;

  TYPE T_PLACE_TABLE_TWO IS TABLE OF T_PLACE_TWO;

  FUNCTION CREATE_PLACE(NEW_PLACE_ID    IN Place.place_id%type,
                        NEW_ADDRESS     IN Place.ADDRESS%type,
                        NEW_ROOM_NUMBER IN Place.ROOM_NUMBER%type,
                        NEW_SCHEULE     IN Place.SCHEDULE%type)
    RETURN VARCHAR2;

  FUNCTION GET_PLACES(P_ID IN Place.place_id%type default null)
    RETURN T_PLACE_TABLE PIPELINED;

  FUNCTION GET_PLACES_ID(P_IDS IN Place.place_id%type default null)
    RETURN T_PLACE_TABLE_TWO PIPELINED;

  FUNCTION UPDATE_PLACE(OLD_P_ID        IN Place.place_id%type,
                        NEW_P_ID        IN Place.place_id%type,
                        NEW_ADDRESS     IN Place.ADDRESS%type,
                        NEW_ROOM_NUMBER IN Place.ROOM_NUMBER%type,
                        NEW_SCHEULE     IN Place.SCHEDULE%type)
    RETURN VARCHAR2;

  FUNCTION DELETE_PLACE(P_ID IN Place.place_id%type)
    RETURN VARCHAR2;
END;
/


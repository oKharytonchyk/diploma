create PACKAGE QUEUE_PACKAGE AS
  TYPE T_QUEUE IS RECORD (
  place_id NUMBER(3),
  user_login VARCHAR2(20),
  status VARCHAR2(20),
  event_name VARCHAR2(50),
  date_creation_event VARCHAR2(10),
  date_request_creation VARCHAR2(10)
  );

  TYPE T_QUEUE_TABLE IS TABLE OF T_QUEUE;

  FUNCTION CREATE_QUEUE(NEW_PLACE_ID              IN QUEUE.PLACE_ID%type,
                        NEW_USER_LOGIN            IN QUEUE.USER_LOGIN%type,
                        NEW_STATUS                IN QUEUE.STATUS%type,
                        NEW_EVENT_NAME            IN QUEUE.EVENT_NAME%type,
                        NEW_DATE_CREATION_EVENT   IN QUEUE.DATE_CREATION_EVENT%type,
                        NEW_DATE_REQUEST_CREATION IN QUEUE.DATE_REQUEST_CREATION%type)
    RETURN VARCHAR2;

  FUNCTION GET_QUEUES(Q_PLACE_ID              IN QUEUE.PLACE_ID%type default null,
                      Q_USER_LOGIN            IN QUEUE.USER_LOGIN%type default null,
                      Q_STATUS                IN QUEUE.STATUS%type default null,
                      Q_EVENT_NAME            IN QUEUE.EVENT_NAME%type default null,
                      Q_DATE_CREATION_EVENT   IN QUEUE.DATE_CREATION_EVENT%type default null,
                      Q_DATE_REQUEST_CREATION IN QUEUE.DATE_REQUEST_CREATION%type default null)
    RETURN T_QUEUE_TABLE PIPELINED;

  FUNCTION UPDATE_QUEUE(OLD_PLACE_ID              IN QUEUE.PLACE_ID%type,
                        OLD_USER_LOGIN            IN QUEUE.USER_LOGIN%type,
                        OLD_STATUS                IN QUEUE.STATUS%type,
                        OLD_EVENT_NAME            IN QUEUE.EVENT_NAME%type,
                        OLD_DATE_CREATION_EVENT   IN QUEUE.DATE_CREATION_EVENT%type,
                        OLD_DATE_REQUEST_CREATION IN QUEUE.DATE_REQUEST_CREATION%type,
                        NEW_PLACE_ID              IN QUEUE.PLACE_ID%type,
                        NEW_USER_LOGIN            IN QUEUE.USER_LOGIN%type,
                        NEW_STATUS                IN QUEUE.STATUS%type,
                        NEW_EVENT_NAME            IN QUEUE.EVENT_NAME%type,
                        NEW_DATE_CREATION_EVENT   IN QUEUE.DATE_CREATION_EVENT%type,
                        NEW_DATE_REQUEST_CREATION IN QUEUE.DATE_REQUEST_CREATION%type)
    RETURN VARCHAR2;

  FUNCTION DELETE_QUEUE(Q_PLACE_ID              IN QUEUE.PLACE_ID%type,
                        Q_USER_LOGIN            IN QUEUE.USER_LOGIN%type,
                        Q_STATUS                IN QUEUE.STATUS%type,
                        Q_EVENT_NAME            IN QUEUE.EVENT_NAME%type,
                        Q_DATE_CREATION_EVENT   IN QUEUE.DATE_CREATION_EVENT%type,
                        Q_DATE_REQUEST_CREATION IN QUEUE.DATE_REQUEST_CREATION%type)
    RETURN VARCHAR2;

END;
/


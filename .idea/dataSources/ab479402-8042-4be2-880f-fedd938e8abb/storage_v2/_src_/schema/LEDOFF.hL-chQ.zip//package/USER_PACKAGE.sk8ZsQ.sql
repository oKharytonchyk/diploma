create PACKAGE USER_PACKAGE AS

  TYPE T_USER IS RECORD (
  user_login VARCHAR2(20),
  --   user_password VARCHAR2(20),
  user_email VARCHAR2(40)
  );

  TYPE T_USER_TABLE IS
    TABLE OF T_USER;

  FUNCTION LOG_IN(LOGIN    IN SuperUser.user_login%TYPE,
                  PASSWORD IN SuperUser.user_password%TYPE)
    RETURN VARCHAR2;

  FUNCTION REGISTER(LOGIN    IN SuperUser.user_login%TYPE,
                    PASSWORD IN SuperUser.user_password%TYPE,
                    EMAIL    IN SuperUser.user_email%TYPE)
    RETURN VARCHAR2;

  FUNCTION GET_USERS(LOGIN IN SuperUser.user_login%TYPE DEFAULT NULL)
    RETURN T_USER_TABLE PIPELINED;

  FUNCTION UPDATE_USER(OLD_LOGIN    IN SuperUser.user_login%TYPE,
                       NEW_LOGIN    IN SuperUser.user_login%TYPE,
                       NEW_PASSWORD IN SuperUser.USER_PASSWORD%TYPE,
                       NEW_EMAIL    IN SuperUser.USER_EMAIL%TYPE)
    RETURN VARCHAR2;

  FUNCTION DELETE_USER(LOGIN IN SuperUser.user_login%TYPE)
    RETURN VARCHAR2;
END;
/


create type          SYS_PLSQL_74815_55_1 as table of LEDOFF."SYS_PLSQL_74815_9_1";
/

